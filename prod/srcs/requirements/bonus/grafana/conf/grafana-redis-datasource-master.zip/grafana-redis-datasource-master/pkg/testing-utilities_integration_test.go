// +build integration

package main

/**
 * Integration Test port
 */
const integrationTestPort = 63790
