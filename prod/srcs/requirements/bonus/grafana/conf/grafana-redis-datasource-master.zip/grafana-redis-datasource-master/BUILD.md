# How to build and install Redis Data Source

You can find detailed instructions in the [Documentation](https://redisgrafana.github.io/development/redis-datasource/).
