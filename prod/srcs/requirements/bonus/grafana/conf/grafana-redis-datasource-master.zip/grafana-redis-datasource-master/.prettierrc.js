module.exports = {
  useTabs: false,
  tabWidth: 2,
  semi: true,
  bracketSpacing: true,
  arrowParens: 'always',
  ...require('./node_modules/@grafana/toolkit/src/config/prettier.plugin.config.json'),
};
