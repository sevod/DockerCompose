---
name: Question 🤔
about: Usage question or discussion about Redis Data Source for Grafana.
title: ''
labels: 'kind/question'
assignees: ''

---
## Summary
<!-- Please include as much useful information as possible. -->

## Relevant information
<!-- Provide as much useful information as you can -->